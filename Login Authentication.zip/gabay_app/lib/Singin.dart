import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import 'Home.dart';
import 'Login.dart';


class Singin extends StatefulWidget {
  const Singin({Key? key}) : super(key: key);

  @override
  State<Singin> createState() => _SinginState();
}

class _SinginState extends State<Singin> {

final auth = FirebaseAuth.instance;
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isLoading = false;

  register() async {
    isLoading = true;
    setState(() {});

    try {
    var data=await  auth.createUserWithEmailAndPassword(
          email: username.text, password: password.text);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('SUCCESS')));
    username.clear();
    password.clear();
   
    } catch (e) {
      print(e);
    }
     isLoading = false;
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: isLoading,
      child: Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          title: Container(child: Text('Sing in',style: TextStyle(fontSize: 20,color: Colors.white),)),
          backgroundColor: Color.fromARGB(255, 108, 232, 249),      
          elevation: 0,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

             Container(
        margin: EdgeInsets.only(left: 15,top: 30,right: 20),
        padding: EdgeInsets.only(left: 10,right: 10,bottom: 5,top: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey.shade200,
        ),
        child: TextField(
          controller: username,
              decoration: InputDecoration(
                hintText: 'Emali',
                border: InputBorder.none,
                //suffixIcon: Icon(CupertinoIcons.search), 
                //suffix: Icon(Icons.person),
               prefixIcon: Icon(CupertinoIcons.person),
              
              ),
            ),
      ),
      Container(
        margin: EdgeInsets.only(left: 15,top: 30,right: 20),
        padding: EdgeInsets.only(left: 10,right: 10,bottom: 5,top: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey.shade200,
        ),
        child: TextField(
          controller: password,
              decoration: InputDecoration(
                hintText: 'Password',
                border: InputBorder.none,
                //suffixIcon: Icon(CupertinoIcons.search),
                //suffix: Icon(Icons.person),
               prefixIcon: Icon(CupertinoIcons.lock),
              
              ),
            ),
      ),




            SizedBox(height: 40,),
            Container(
              width: double.infinity,
              height: 55,
              margin: EdgeInsets.only(left: 15,right: 20),
              child: ElevatedButton(onPressed:() {
                register();

                StreamBuilder(
                stream: FirebaseAuth.instance.authStateChanges(),
                builder: (context, snapshot) {
                if(snapshot.hasData){
                    return Home();
                 }
                else{
                     return  Singin();
                    }
                },);
              },
               child: Text('Singin',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600),),
               style: ElevatedButton.styleFrom(
                primary: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)
                )
               ),
               ),
            )
          ],
        ),
      ),
    );
  }
}
